var sqlite3 = require('sqlite3');

module.exports = new sqlite3.Database("/Websites/1_db.jyelewis.com/database.db")